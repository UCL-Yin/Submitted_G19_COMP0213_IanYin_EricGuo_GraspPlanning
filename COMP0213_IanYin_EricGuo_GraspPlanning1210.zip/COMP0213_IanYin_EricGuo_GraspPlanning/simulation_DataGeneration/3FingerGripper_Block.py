import pybullet as p
import os
import pybullet_data
import time
import math
from collections import namedtuple
import numpy as np
import pandas as pd
import random

class Object:
    def __init__(self, urdf_path, start_pos,scale=1):
        self.urdf_path = urdf_path
        self.start_pos = start_pos
        self.id = p.loadURDF(self.urdf_path, self.start_pos, globalScaling=scale)

    def get_pose(self):
        pos, ori = p.getBasePositionAndOrientation(box_id)
        return pos
class Gripper:
    def __init__(self, urdf_path, start_pos, start_ori):
        self.urdf_path = urdf_path
        self.start_pos = start_pos
        self.start_ori = start_ori
        self.id = p.loadURDF(self.urdf_path,self.start_pos,self.start_ori,useFixedBase=True)
        num_joints = p.getNumJoints(self.id)
        JointInfo = namedtuple('JointInfo',['id','name','type','lower','upper','maxForce'])
        self.joints = []
        for i in range(num_joints):
            info = p.getJointInfo(self.id, i)
            jid = info[0]
            name = info[1].decode()
            jtype = info[2]
            lower = info[8]
            upper = info[9]
            maxForce = info[10]
            self.joints.append(JointInfo(jid,name,jtype,lower,upper,maxForce))
            p.setJointMotorControl2(self.id,jid,p.VELOCITY_CONTROL,targetVelocity=0,force=0)

    # def open(self):
    #     self.move_gripper(0.085)

    # def close(self):
    #     self.move_gripper(0)

    def move_gripper(self,open_length):
        open_angle = 0.715 - math.asin((open_length-0.010)/0.1143)
        p.setJointMotorControl2(self.id,self.mimic_parent_id,p.POSITION_CONTROL,
                            targetPosition=open_angle, force=60)  
        return open_angle

    def set_gripper_position(self,pos,ori):
        p.resetBasePositionAndOrientation(self.id,pos,ori)
    
    def execute_gripper(self):
        target_velocity = [0, 0, 0.5] 
        p.resetBaseVelocity(self.id, target_velocity, [0, 0, 0])
        self.move_gripper(0) 
class ThreeFingerGripper(Gripper):
    GRASP_JOINTS = [0, 3, 6]
    PRESHAPE_JOINTS = [1, 4, 7]
    UPPER_JOINTS = [2, 5, 8]

    def __init__(self, urdf_path, start_pos, start_ori):
        super().__init__(urdf_path, start_pos, start_ori)
        self.num_joints = p.getNumJoints(self.id)
        for joint in self.joints:
            print(f"Joint ID: {joint.id}, Name: {joint.name}")
        for j in (self.GRASP_JOINTS):
            p.setJointMotorControl2(
            self.id,
            j,
            p.VELOCITY_CONTROL,
            force=0
    )
            self.setup_mimic_joints()
    def setup_mimic_joints(self):


        self.mimic_constraints = []

        # （1）Finger 1
        master = 1   # finger_12_joint
        slaves = [2] # finger_13_joint
        for s in slaves:
            cid = p.createConstraint(
                self.id, master,    # parent body, parent joint
                self.id, s,         # child body, child joint
                jointType=p.JOINT_FIXED,
                jointAxis=[0, 0, 0],
                parentFramePosition=[0, 0, 0],
                childFramePosition=[0, 0, 0.2]
            )
            # gearRatio = -multiplier ; 使用 1:1 比例
            p.changeConstraint(cid, gearRatio=-1, maxForce=50, erp=1)
            self.mimic_constraints.append(cid)


        # （2）Finger 2
        master = 3   # finger_21_joint
        slaves = [4, 5]  # finger_22, finger_23
        for s in slaves:
            cid = p.createConstraint(
            self.id, master,
            self.id, s,
            jointType=p.JOINT_GEAR,
            jointAxis=[0, 1, 0],
            parentFramePosition=[0, 0, 0],
            childFramePosition=[0, 0, 0]
        )
        p.changeConstraint(cid, gearRatio=-1, maxForce=50, erp=1)
        self.mimic_constraints.append(cid)


        # （3）Thumb
        master = 6   # thumb_1_joint
        slaves = [7, 8]
        for s in slaves:
            cid = p.createConstraint(
            self.id, master,
            self.id, s,
            jointType=p.JOINT_GEAR,
            jointAxis=[0, 1, 0],
            parentFramePosition=[0, 0, 0],
            childFramePosition=[0, 0, 0]
        )
        p.changeConstraint(cid, gearRatio=-1, maxForce=50, erp=1)
        self.mimic_constraints.append(cid)



    def open(self):
        """Open all three fingers."""
        for j in self.UPPER_JOINTS:
            p.setJointMotorControl2(self.id, j, p.POSITION_CONTROL,
                                    targetPosition=0.1, maxVelocity=8,force=60)
        for j in self.GRASP_JOINTS:
            p.setJointMotorControl2(self.id, j, p.POSITION_CONTROL,
                                    targetPosition=0.2, maxVelocity=8,force=60)
        for j in self.PRESHAPE_JOINTS:
            p.setJointMotorControl2(self.id, j, p.POSITION_CONTROL,
                                    targetPosition=-1.3, maxVelocity=8,force=60)

    def close(self):
        """Close all fingers into grasping position."""
        angle = 0.6
        for j in self.PRESHAPE_JOINTS:
            p.setJointMotorControl2(self.id, j, p.POSITION_CONTROL,
                                    targetPosition=0, maxVelocity=8, force=60)
        for j in self.UPPER_JOINTS:
            p.setJointMotorControl2(self.id, j, p.POSITION_CONTROL,
                                    targetPosition=0.3, maxVelocity=8, force=60)
        for j in self.GRASP_JOINTS:
            p.setJointMotorControl2(self.id, j, p.POSITION_CONTROL,
                                    targetPosition=0.8, maxVelocity=8,force=60)
    def execute_gripper(self):
        """Lift the gripper upward while maintaining closure."""
        p.resetBaseVelocity(self.id, [0, 0, 0.5], [0, 0, 0])
        self.close()  # Keep grasp closed during lifting



# ---------- Setup ----------
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.resetSimulation()
p.setGravity(0,0,-10)

columns = ['x','y','z','pitch','yaw','success']
df = pd.DataFrame(columns=columns)
plane_id = p.loadURDF("plane.urdf")
current_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(current_dir)


p.resetDebugVisualizerCamera(
    cameraDistance=0.8,
    cameraYaw=180,
    cameraPitch=-30,
    cameraTargetPosition=[0.6, 0.3, 0.2]
)
for n in range(20):
    cube_path = os.path.join(parent_dir,"urdf", "cube_small.urdf")
    cube = Object(cube_path,[0.6, 0.3, 0.025])
    #ball= Object("duck_vhacd.urdf",[0.6, 0.3, 0.025],scale=1.2)
    height = np.random.uniform(0.21, 0.25)
    height = np.round(height,3)
    heightori=0.5
    xpos = np.random.uniform(0.55, 0.65)
    xpos = np.round(xpos,3)
    ypos = np.random.uniform(0.25, 0.35)
    ypos = np.round(ypos,3)
    random_pitch = np.round(random.uniform(-math.pi / 12, math.pi / 12),3)
    random_yaw = np.round(random.uniform(-math.pi / 3, math.pi / 3),3)
    gripper_start_pos1 = [xpos,ypos,height]
    gripper_start_pos0 = [xpos,ypos,heightori]
    gripper_start_ori = p.getQuaternionFromEuler([3.1416,random_pitch, random_yaw])
    gripper_urdf = os.path.join(parent_dir,"urdf", "threeFingers", "sdh","sdh.urdf")
    tfgripper = ThreeFingerGripper(gripper_urdf, gripper_start_pos0, gripper_start_ori)
    currentpos = gripper_start_pos0

    tfgripper.open()
    for _ in range(80): p.stepSimulation(); time.sleep(0.01)
    for i in range(135):
        current_pos, current_ori = p.getBasePositionAndOrientation(tfgripper.id)
        target_velocity = [0, 0, -0.45] 
        p.resetBaseVelocity(tfgripper.id, target_velocity, [0, 0, 0])
        tfgripper.open()
        p.stepSimulation()
        time.sleep(0.005)
        
    for i in range(5):
        current_pos, current_ori = p.getBasePositionAndOrientation(tfgripper.id)
        target_velocity = [0, 0, 0] 
        p.resetBaseVelocity(tfgripper.id, target_velocity, [0, 0, 0])
        tfgripper.close()
        p.stepSimulation()
        time.sleep(0.001)   
        
    for i in range(200):
        tfgripper.close()
        p.stepSimulation()
        time.sleep(0.01)
    for i in range(600):
        current_pos, current_ori = p.getBasePositionAndOrientation(tfgripper.id)
        target_velocity = [0, 0, 0.2] 
        p.resetBaseVelocity(tfgripper.id, target_velocity, [0, 0, 0])
        tfgripper.close()
        p.stepSimulation()
        time.sleep(0.005)
        
    #contacts = p.getContactPoints(tfgripper.id, cube.id)
    contacts = p.getContactPoints(tfgripper.id, cube.id)
    success = 1 if len(contacts) > 0 else 0

    gripper_start_pos2=gripper_start_pos1.copy()
    gripper_start_pos2.extend([random_pitch,random_yaw])
    currentpos = gripper_start_pos2
    df.loc[len(df)] = currentpos + [success]
    print(f"Iteration {n}, Success: {success}")
    p.removeBody(tfgripper.id)
    #p.removeBody(cube.id)
    p.removeBody(cube.id)
    time.sleep(0.5)

df.to_csv("3FingerGripper_grasp_dataset.csv", index=False)
p.disconnect()
print("Simulation finished and data saved.")
print(df)
