import os
import pybullet as p
import pybullet_data
import time
import math
from collections import namedtuple
import numpy as np
import pandas as pd
import random

class Object:
    def __init__(self, urdf_path, start_pos):
        self.urdf_path = urdf_path
        self.start_pos = start_pos
        self.id = p.loadURDF(self.urdf_path, self.start_pos)

    def get_pose(self):
        pos, ori = p.getBasePositionAndOrientation(self.id)
        return pos

class Gripper:
    def __init__(self, urdf_path, start_pos, start_ori):
        self.urdf_path = urdf_path
        self.start_pos = start_pos
        self.start_ori = start_ori
        self.id = p.loadURDF(self.urdf_path, self.start_pos, self.start_ori, useFixedBase=False)
        num_joints = p.getNumJoints(self.id)
        JointInfo = namedtuple('JointInfo',['id','name','type','lower','upper','maxForce'])
        self.joints = []
        for i in range(num_joints):
            info = p.getJointInfo(self.id, i)
            jid = info[0]
            name = info[1].decode()
            jtype = info[2]
            lower = info[8]
            upper = info[9]
            maxForce = info[10]
            self.joints.append(JointInfo(jid,name,jtype,lower,upper,maxForce))
            p.setJointMotorControl2(self.id,jid,p.VELOCITY_CONTROL,targetVelocity=0,force=0)

    def open(self):
        self.move_gripper(0.085)

    def close(self):
        self.move_gripper(0)

    def move_gripper(self,open_length):
        open_angle = 0.715 - math.asin((open_length-0.010)/0.1143)
        p.setJointMotorControl2(self.id,self.mimic_parent_id,p.POSITION_CONTROL,
                            targetPosition=open_angle, force=60)  
        return open_angle

    def set_gripper_position(self,pos,ori):
        p.resetBasePositionAndOrientation(self.id,pos,ori)
    
    def execute_gripper(self):
        target_velocity = [0, 0, 0.5] 
        p.resetBaseVelocity(self.id, target_velocity, [0, 0, 0])
        self.move_gripper(0) 

class TwoFingerGripper(Gripper):
    def __init__(self, urdf_path, start_pos, start_ori):
        super().__init__(urdf_path, start_pos, start_ori)
        self.setup_mimic_joints()

    def setup_mimic_joints(self):
        mimic_parent_name = 'finger_joint'
        mimic_children_names = {'right_outer_knuckle_joint':1,
                        'left_inner_knuckle_joint':1,
                        'right_inner_knuckle_joint':1,
                        'left_inner_finger_joint':-1,
                        'right_inner_finger_joint':-1}

        self.mimic_parent_id = [j.id for j in self.joints if j.name==mimic_parent_name][0]
        mimic_child_multiplier = {j.id: mimic_children_names[j.name] for j in self.joints if j.name in mimic_children_names}
        for joint_id, multiplier in mimic_child_multiplier.items():
            c = p.createConstraint(self.id,self.mimic_parent_id,
                           self.id,joint_id,
                           jointType=p.JOINT_GEAR,
                           jointAxis=[0,1,0],
                           parentFramePosition=[0,0,0],
                           childFramePosition=[0,0,0])
            p.changeConstraint(c,gearRatio=-multiplier,maxForce=100,erp=1)

p.connect(p.GUI)
p.resetSimulation()
p.setGravity(0,0,-10)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
current_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(current_dir)
plane_path = os.path.join(pybullet_data.getDataPath(), "plane.urdf")
plane_id = p.loadURDF(plane_path)
p.resetDebugVisualizerCamera(
    cameraDistance=0.5,
    cameraYaw=40,
    cameraPitch=-30,
    cameraTargetPosition=[0.6, 0.3, 0.2]
)
columns = ['x','y','z','pitch','yaw','success']
df = pd.DataFrame(columns=columns)

for n in range(25):
    cube_path = os.path.join(parent_dir,"urdf", "cube_small.urdf")
    cube = Object(cube_path, [0.6, 0.3, 0.025])
    height = np.round(np.random.uniform(0.28, 0.32), 3)
    xpos = np.round(np.random.uniform(0.58, 0.62), 3)
    ypos = np.round(np.random.uniform(0.28, 0.32), 3)
    gripper_start_pos = [xpos, ypos, height]
    random_pitch = np.round(random.uniform(-math.pi / 8, math.pi / 8),3)
    random_yaw = np.round(random.uniform(-math.pi / 12, math.pi / 12),3)
    gripper_start_ori = p.getQuaternionFromEuler([3.1416, random_pitch, random_yaw])
    gripper_urdf = os.path.join(parent_dir,"urdf", "robotiq_2f_85", "robotiq.urdf")
    gripper = TwoFingerGripper(gripper_urdf, gripper_start_pos, gripper_start_ori)
    gripper.open()
    for _ in range(100): 
        p.stepSimulation()
        time.sleep(0.001)
    for step in range(150):
        gripper.close()
        p.stepSimulation()
        time.sleep(0.001)
    for i in range(300):
        current_pos, current_ori = p.getBasePositionAndOrientation(gripper.id)
        gripper.execute_gripper()
        p.stepSimulation()
        time.sleep(0.01)
    contacts = p.getContactPoints(gripper.id, cube.id)
    success = 1 if len(contacts) > 0 else 0
    gripper_start_pos2=gripper_start_pos.copy()
    gripper_start_pos2.extend([random_pitch,random_yaw])
    currentpos = gripper_start_pos2
    df.loc[len(df)] = currentpos + [success]
    print(f"Iteration {n}, Success: {success}")
    p.removeBody(gripper.id)
    p.removeBody(cube.id)
    time.sleep(0.5)
df.to_csv("2FingerGripper_grasp_dataset.csv", index=False)
p.disconnect()
print("Simulation finished and data saved.")
print(df)